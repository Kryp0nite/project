---
home: true
actionText: Get Started →
actionLink: /guide/
footer: MIT Licensed | Made with love by DIYgod
---

<div>
  <DPlayer :immediate="true"></DPlayer>
</div>

<div class="hero custom"><p class="action"><router-link to="/guide/" class="nav-link action-button">Get Started →</router-link></p></div>
