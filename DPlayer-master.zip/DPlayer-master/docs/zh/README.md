---
home: true
actionText: Get Started →
actionLink: /zh/guide/
footer: MIT Licensed | Made with love by DIYgod
---

<div>
  <DPlayer :immediate="true"></DPlayer>
</div>

<div class="hero custom"><p class="action"><router-link to="/zh/guide/" class="nav-link action-button">快速上手 →</router-link></p></div>
